package com.example.diceroller

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Button
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.diceroller.ui.theme.DiceRollerTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DiceRollerTheme {
                DiceRollerApp()
                // A surface container using the 'background' color from the theme

            }
        }
    }
}



@Preview
@Composable
fun DiceRollerApp() {
    DiceWithButtonAndImage(modifier = Modifier
        .fillMaxSize()
        .wrapContentSize())
}

@Composable
fun DiceWithButtonAndImage(modifier: Modifier = Modifier) {
    var result by remember { mutableStateOf(1) }
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        DiceFace(result)
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = { result = (1..10).random() }) {
            Text(stringResource(R.string.roll))
        }
    }
}

@Composable
fun DiceFace(value: Int, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(150.dp)
            .background(Color.White, shape = RoundedCornerShape(12.dp))
            .border(2.dp, Color.Black, shape = RoundedCornerShape(12.dp))
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val rows = (value + 2) / 3
            for (r in 0 until rows) {
                Row(
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val dotsInThisRow = if (r < rows - 1) 3 else {
                        val remaining = value % 3
                        if (remaining == 0) 3 else remaining
                    }
                    repeat(dotsInThisRow) {
                        Box(
                            modifier = Modifier
                                .padding(4.dp)
                                .size(20.dp)
                                .background(Color.Black, shape = CircleShape)
                        )
                    }
                }
            }
        }
    }
}